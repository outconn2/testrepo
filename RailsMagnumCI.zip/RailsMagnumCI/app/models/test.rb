class Test < ActiveRecord::Base
end
